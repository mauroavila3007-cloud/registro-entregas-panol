# Registro de entregas del pañol — v1.2 (proyecto fuente Android)

## Funciones previstas en esta versión
- Captura de etiqueta con la cámara Android.
- Archivo de fotografía guardado en almacenamiento interno (`filesDir/delivery_photos/`).
- URI segura mediante `FileProvider` (se crea el archivo antes de solicitar la URI).
- OCR de ML Kit ejecutado desde el archivo local; código y descripción quedan editables.
- Registro offline en Room con URI de foto y texto OCR asociado.
- Historial con indicador de fotografía.
- Registro de parte/tarea, repuesto, cantidad entregada, usuario, stocks observados y fecha/hora.

## Compilar en Android Studio
1. Abrir esta carpeta raíz como proyecto Android.
2. Sincronizar Gradle con conexión a internet para descargar dependencias.
3. Tener instalado Android SDK 35.
4. Ejecutar `app` o elegir Build > Build APK(s).

## Estado verificado en este entorno
Este ZIP es el proyecto fuente, no un APK. El entorno de esta sesión no tiene Gradle ni Android SDK instalados, por lo que no fue posible compilar ni probar la app en un dispositivo. El ZIP se verificó después de crearlo (integridad y contenido). No considerar el APK terminado hasta compilarlo y probarlo en Android Studio/dispositivo.

OCR: el texto reconocido se propone en código y descripción; revisar/corregir antes de guardar.
