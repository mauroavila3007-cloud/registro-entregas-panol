package ar.com.panol.entregas.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "deliveries")
data class Delivery(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskNumber: String,
    val itemCode: String,
    val itemDescription: String,
    val quantity: Int,
    val systemStock: String,
    val physicalStock: String,
    val photoUri: String,
    val ocrText: String,
    val userName: String,
    val timestamp: Long = System.currentTimeMillis()
) {
    val hasPhoto: Boolean get() = photoUri.isNotBlank()
}
