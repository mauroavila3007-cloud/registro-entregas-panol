package ar.com.panol.entregas.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Delivery::class], version = 1, exportSchema = true)
abstract class DeliveryDatabase : RoomDatabase() {
    abstract fun deliveryDao(): DeliveryDao
    companion object {
        @Volatile private var INSTANCE: DeliveryDatabase? = null
        fun get(context: Context): DeliveryDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, DeliveryDatabase::class.java, "panol_deliveries.db").build().also { INSTANCE = it }
        }
    }
}
