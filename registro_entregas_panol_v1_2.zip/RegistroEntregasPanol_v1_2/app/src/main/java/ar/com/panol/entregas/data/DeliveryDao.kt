package ar.com.panol.entregas.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DeliveryDao {
    @Insert suspend fun insert(delivery: Delivery): Long
    @Query("SELECT * FROM deliveries ORDER BY timestamp DESC") fun observeAll(): Flow<List<Delivery>>
    @Query("SELECT * FROM deliveries WHERE id = :id LIMIT 1") suspend fun findById(id: Long): Delivery?
}
