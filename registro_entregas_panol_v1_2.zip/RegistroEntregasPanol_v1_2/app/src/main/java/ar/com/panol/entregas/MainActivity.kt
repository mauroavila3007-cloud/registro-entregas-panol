package ar.com.panol.entregas

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import ar.com.panol.entregas.data.Delivery
import ar.com.panol.entregas.data.DeliveryDatabase
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    private val dao by lazy { DeliveryDatabase.get(this).deliveryDao() }
    private var pendingPhoto: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF245B9E))) {
                var task by remember { mutableStateOf("") }
                var code by remember { mutableStateOf("") }
                var description by remember { mutableStateOf("") }
                var qty by remember { mutableStateOf("1") }
                var sys by remember { mutableStateOf("") }
                var physical by remember { mutableStateOf("") }
                var user by remember { mutableStateOf("") }
                var photoUri by remember { mutableStateOf("") }
                var ocr by remember { mutableStateOf("") }
                var status by remember { mutableStateOf("Preparado para registrar entregas sin conexión.") }
                val history by dao.observeAll().collectAsState(initial = emptyList())

                val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
                    if (ok && pendingPhoto != null) {
                        photoUri = pendingPhoto.toString()
                        status = "Foto guardada en almacenamiento interno. Procesando OCR…"
                        lifecycleScope.launch {
                            try {
                                val image = InputImage.fromFilePath(this@MainActivity, pendingPhoto!!)
                                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                                val result = withContext(Dispatchers.IO) { recognizer.process(image).awaitText() }
                                ocr = result
                                status = if (result.isBlank()) "Foto guardada; OCR no detectó texto. Revisá manualmente." else "OCR listo. Revisá código y descripción antes de guardar."
                                val firstLine = result.lines().firstOrNull { it.isNotBlank() }.orEmpty()
                                if (code.isBlank()) code = firstLine.take(40)
                                if (description.isBlank()) description = result.lines().drop(1).firstOrNull { it.isNotBlank() }.orEmpty().take(100)
                            } catch (e: Exception) { status = "Foto guardada, pero falló OCR: ${e.localizedMessage ?: "error"}" }
                        }
                    } else status = "No se capturó la foto."
                }

                Column(Modifier.fillMaxSize().padding(16.dp)) {
                    Text("Registro de entregas del pañol", style = MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(task, { task = it }, label = { Text("Número de parte / tarea *") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(user, { user = it }, label = { Text("Usuario / pañolero *") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(code, { code = it }, label = { Text("Código detectado (editable)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(description, { description = it }, label = { Text("Descripción (editable)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(qty, { qty = it }, label = { Text("Cantidad entregada *") }, modifier = Modifier.fillMaxWidth())
                    Row(Modifier.fillMaxWidth()) {
                        OutlinedTextField(sys, { sys = it }, label = { Text("Stock sistema") }, modifier = Modifier.weight(1f))
                        Spacer(Modifier.width(8.dp))
                        OutlinedTextField(physical, { physical = it }, label = { Text("Stock físico") }, modifier = Modifier.weight(1f))
                    }
                    Button(onClick = {
                        val folder = File(filesDir, "delivery_photos").apply { mkdirs() }
                        val photo = File(folder, "delivery_${System.currentTimeMillis()}.jpg")
                        photo.createNewFile() // FileProvider requiere que el archivo exista antes de crear la URI.
                        pendingPhoto = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", photo)
                        camera.launch(pendingPhoto)
                    }, modifier = Modifier.fillMaxWidth()) { Text(if (photoUri.isBlank()) "Fotografiar etiqueta" else "Volver a fotografiar etiqueta") }
                    Text(status, style = MaterialTheme.typography.bodySmall)
                    Button(onClick = {
                        if (task.isBlank() || user.isBlank() || qty.toIntOrNull()?.let { it > 0 } != true || photoUri.isBlank()) {
                            status = "Completá tarea, usuario, cantidad válida y fotografía."; return@Button
                        }
                        lifecycleScope.launch {
                            dao.insert(Delivery(taskNumber = task.trim(), itemCode = code.trim(), itemDescription = description.trim(), quantity = qty.toInt(), systemStock = sys.trim(), physicalStock = physical.trim(), photoUri = photoUri, ocrText = ocr, userName = user.trim()))
                            status = "Entrega guardada en Room con evidencia fotográfica."
                            task = ""; code = ""; description = ""; qty = "1"; sys = ""; physical = ""; photoUri = ""; ocr = ""
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Guardar entrega") }
                    Spacer(Modifier.height(12.dp))
                    Text("Historial · ${history.size} entregas", style = MaterialTheme.typography.titleMedium)
                    LazyColumn(Modifier.weight(1f)) {
                        items(history) { item ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Column(Modifier.padding(10.dp)) {
                                    Text("${item.itemDescription.ifBlank { "Repuesto sin descripción" }} · ${item.quantity} un.", style = MaterialTheme.typography.titleSmall)
                                    Text("Parte/tarea: ${item.taskNumber} · Código: ${item.itemCode}")
                                    Text("Stock sistema: ${item.systemStock.ifBlank { "s/d" }} · Físico: ${item.physicalStock.ifBlank { "s/d" }}")
                                    Text("${if (item.hasPhoto) "📷 Tiene foto" else "Sin foto"} · ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(item.timestamp))}", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private suspend fun com.google.android.gms.tasks.Task<com.google.mlkit.vision.text.Text>.awaitText(): String =
    kotlinx.coroutines.suspendCancellableCoroutine { cont ->
        addOnSuccessListener { if (cont.isActive) cont.resume(it.text, null) }
        addOnFailureListener { if (cont.isActive) cont.resumeWith(Result.failure(it)) }
    }
